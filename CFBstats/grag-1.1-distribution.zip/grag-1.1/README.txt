GRAG - Grails Application Generator
================================

>To run:
CD bin
gui

or 
./gui.sh

on UNIX-like systems. Make sure the the gui.sh is exucutable (chmod +x gui.sh)

-enjoy!
